# -*- coding: utf8 -*-
import logging, threading
import server_forever
import re
import sqlite3
import sys, os, commands
import pytesseract
from PIL import Image

class O2O_Server(server_forever.Server):
    def handle(self):
        self.data = self.conn.recv(1024)
        if self.data:
            logging.debug('Received from {}: {}'.format(self.conn.getpeername(),self.data))
            request_msg = self.data.split()

            if((request_msg[0] == 'CHECK') and (requeset_msg[1] == 'LOGIN') and len(request_msg) == 4): # login 시도
                result = self.check_login(request_msg[2],request_msg[3])
                if result == 'success':
                    self.conn.sendall('200 OK '+ result + '\n')
                elif result == 'fail':
                    self.conn.sendall('405 Failed information'+ '\n')

            elif((request_msg[0] == 'CHECK') and (request_msg[1] == 'REPITITION') and len(request_msg) == 3):
                result = self.check_repitition(request_msg[2])
                if result == 'Existent':
                    self.conn.sendall('200 OK\n')
                elif result == 'Nonexistent':
                    self.conn.sendall('410 Nothing Register ID\n')

            elif((request_msg[0] == 'CHECK') and (request_msg[1] == 'REGISTER') and len(request_msg) == 5):
                self.check_register(request_msg[2],request_msg[3],requset_msg[4])
                self.conn.sendall('200 OK\n')
            
            
        pass


#--------------------------------------------------------------------------------------------------------------------------------#
    def check_login(self,id,password): # 로그인 시 -> id와 password를 db에서 확인하여 로그인 처리
        check = 1 #!!!!!!!!!!!!!!!!!!!!!!!!!!!db에서 id와 password 검사하는 코드짜기
        if check == 1:
            return 'success'
        else:
            return 'fail'

    def check_repitation(self,id): # 중복확인 시 -> id가 db에 있는지 확인
        check = 1 #!!!!!!!!!!!!!!!!!!!!!!!!!!!!db에 id가 있는지 검사하는 코드 짜기
        if check == 1:
            return 'Existent'
        else:
            return 'Nonexistent'

    def check_register(self,id,password,name):
        #!!!!!!!!!!!!!!db에 id,password,name을 insert하는 코드 짜기
        pass

    ###################def register_id(self,id,password,name) -> id와 password, 이름에 대한 정보를 넘겨받는다
    # db에 insert 한다 


    ###################def getphoto() -> id와 업로드 한 사진 받아와 전처리 과정
    
    ###################def convert_tesseract() -> 전처리된 사진에 대해 id와

    ###################def make_traineddata()  -> 아이디와 그에 해당하는 traind data만들기

#--------------------------------------------------------------------------------------------------------------------------------#
if __name__=="__main__":
    logging.basicConfig(level=logging.DEBUG)
    server = O2O_Server('192.168.0.11',8888)
    server.serve()
